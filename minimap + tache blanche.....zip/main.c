#include "minimap.h"
#include <SDL2/SDL_mixer.h>

int main() {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

    SDL_Window   *window   = SDL_CreateWindow("Jeu", 100, 100, 800, 600, 0);
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    MiniMap  m;
    SousMenu sm;
    init_minimap(&m, renderer);
    sm = init_SousMenu(renderer);

    /* ── Variables des autres équipes ── */
    int score   = 0;
    int sang1   = 100;
    int sang2   = 100;
    int timer   = 0;
    int cameraX = 0;
    int cameraY = 0;
    int nb_cles = 0;

    /* ── Ennemi ── */
    int ennemi_x    = 300;
    int ennemi_y    = 200;
    int ennemi_sang = 100;

    /* ── CHARGEMENT : si une sauvegarde existe, on restaure tout ── */
    charger_jeu(&m, &score, &sang1, &sang2,
                &timer, &cameraX, &cameraY,
                &nb_cles,
                &ennemi_x, &ennemi_y, &ennemi_sang,
                "savegame.bin");

    /* interface : 3=jeu  4=sous-menu sauvegarde */
    int interface = 3;

    SDL_Rect joueur     = {m.joueur1X, m.joueur1Y, 50, 50};
    SDL_Rect plateforme = {400, 300, 100, 20};

    int running = 1;
    SDL_Event e;

    while (running) {

        /* ── Événements ── */
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) running = 0;

            if (e.type == SDL_KEYDOWN) {

                /* ECHAP → ouvrir / fermer le sous-menu */
                if (e.key.keysym.sym == SDLK_ESCAPE)
                    interface = (interface == 3) ? 4 : 3;

                /* Déplacement joueur (seulement si jeu actif) */
                if (interface == 3) {
                    int newX = m.joueur1X;
                    int newY = m.joueur1Y;
                    switch (e.key.keysym.sym) {
                        case SDLK_RIGHT: newX += 10; break;
                        case SDLK_LEFT:  newX -= 10; break;
                        case SDLK_UP:    newY -= 10; break;
                        case SDLK_DOWN:  newY += 10; break;
                        default: break;
                    }
                    SDL_Rect test = {newX, newY, joueur.w, joueur.h};
                    if (!collision_BB(test, plateforme) &&
                        !collision_PP(&m, newX, newY)) {
                        m.joueur1X = newX;
                        m.joueur1Y = newY;
                    } else {
                        minimap_trigger_shake(&m);
                    }
                }

                /* Navigation sous-menu */
                if (interface == 4) {
                    int retour = update_SousMenu(&sm, e.key.keysym.sym);

                    if (retour == -1) {
                        /* ── SAUVEGARDER ── */
                        sauvegarder_jeu(m, score, sang1, sang2,
                                        timer, cameraX, cameraY,
                                        nb_cles,
                                        ennemi_x, ennemi_y, ennemi_sang,
                                        "savegame.bin");
                        interface = 3;
                    }
                    else if (retour == 3) {
                        /* ── RESUME ── */
                        interface = 3;
                    }
                }
            }
        }

        /* ── Mise à jour ── */
        minimap_update_shake(&m);
        MAJ_minimap(&m, m.joueur1X, m.joueur1Y, 10);
        joueur.x = m.joueur1X;
        joueur.y = m.joueur1Y;

        /* ── Affichage ── */
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
        SDL_RenderClear(renderer);

        afficher_minimap(m, renderer);

        if (interface == 4)
            afficher_SousMenu(sm, renderer);

        SDL_RenderPresent(renderer);
        SDL_Delay(16);
    }

    /* ── Libération ── */
    liberer_SousMenu(&sm);
    liberer_minimap(&m);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    Mix_CloseAudio();
    SDL_Quit();
    return 0;
}

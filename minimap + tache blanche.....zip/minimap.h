#ifndef MINIMAP_H
#define MINIMAP_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>

/* ── MiniMap ── */
typedef struct {
    SDL_Texture *img_map1;
    SDL_Texture *img_map2;
    SDL_Texture *img_point;
    SDL_Surface *img_mask1;
    SDL_Surface *img_mask2;
    SDL_Rect pos_map;
    SDL_Rect pos_point;
    int joueur1X, joueur1Y;
    int joueur2X, joueur2Y;
    int num_level;
    int shakeTimer;
    int shakeIntensity;
    int shakeOffsetX;
    int shakeOffsetY;
} MiniMap;

/* ── Sous-menu sauvegarde ── */
typedef struct {
    SDL_Texture *img_bg;
    SDL_Rect     pos_bg;
    SDL_Texture *btn_save[2];
    SDL_Texture *btn_resume[2];
    SDL_Rect     pos_save;
    SDL_Rect     pos_resume;
    Mix_Chunk   *son_clic;
    Mix_Music   *musique;
    int          btn_actif; /* 1=Save  2=Resume */
} SousMenu;

/* ── Prototypes MiniMap ── */
void init_minimap(MiniMap *m, SDL_Renderer *re);
void afficher_minimap(MiniMap m, SDL_Renderer *re);
void MAJ_minimap(MiniMap *m, int x, int y, int ratio);
int  collision_PP(MiniMap *m, int x, int y);
int  collision_BB(SDL_Rect a, SDL_Rect b);
void minimap_trigger_shake(MiniMap *m);
void minimap_update_shake(MiniMap *m);
void liberer_minimap(MiniMap *m);

/* ── Prototypes Sous-menu ── */
SousMenu init_SousMenu(SDL_Renderer *re);
void     afficher_SousMenu(SousMenu sm, SDL_Renderer *re);
int      update_SousMenu(SousMenu *sm, int input);
void     liberer_SousMenu(SousMenu *sm);

/* ── Prototypes Sauvegarde ── */
void sauvegarder_jeu(MiniMap m, int score,
                     int sang1, int sang2,
                     int timer, int cameraX, int cameraY,
                     int nb_cles,
                     int ennemi_x, int ennemi_y, int ennemi_sang,
                     char *nomF);

void charger_jeu(MiniMap *m, int *score,
                 int *sang1, int *sang2,
                 int *timer, int *cameraX, int *cameraY,
                 int *nb_cles,
                 int *ennemi_x, int *ennemi_y, int *ennemi_sang,
                 char *nomF);

#endif

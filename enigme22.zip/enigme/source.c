#include "header.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define W 800
#define H 600

int charger(Enigme t[], int *n) {
    FILE *f = fopen("questions.txt", "r");
    if (!f) return 0;

    *n = 0;
    while (!feof(f)) {
        fscanf(f, "Q: %[^\n]\n", t[*n].question);
        fscanf(f, "A: %[^\n]\n", t[*n].A);
        fscanf(f, "B: %[^\n]\n", t[*n].B);
        fscanf(f, "C: %[^\n]\n", t[*n].C);
        fscanf(f, "R: %c\n\n", &t[*n].correcte);
        t[*n].dejaVu = 0;
        (*n)++;
    }

    fclose(f);
    return 1;
}

int generer(Enigme t[], int n) {
    int i;
    do {
        i = rand() % n;
    } while (t[i].dejaVu);

    t[i].dejaVu = 1;
    return i;
}

SDL_Texture* renderText(char *msg, TTF_Font *font, SDL_Color color, SDL_Renderer *renderer) {
    SDL_Surface *surf = TTF_RenderUTF8_Blended(font, msg, color);
    SDL_Texture *tex = SDL_CreateTextureFromSurface(renderer, surf);
    SDL_FreeSurface(surf);
    return tex;
}

void drawText(SDL_Texture *tex, int x, int y, SDL_Renderer *renderer) {
    SDL_Rect r;
    SDL_QueryTexture(tex, NULL, NULL, &r.w, &r.h);
    r.x = x;
    r.y = y;
    SDL_RenderCopy(renderer, tex, NULL, &r);
}




void rotozoom(SDL_Renderer *rend, SDL_Texture *tex, int win) {
    Uint32 t0 = SDL_GetTicks();
    double angle = 0;
    SDL_Event e;
    while (SDL_GetTicks() - t0 < 3000) {
        SDL_PollEvent(&e);
        angle += 4;
        float s = 1.0f + 0.28f * (float)sin((SDL_GetTicks() - t0) * 0.006);
        SDL_Rect dst = { W/2 - (int)(250*s), H/2 - (int)(55*s), (int)(500*s), (int)(110*s) };
        SDL_SetRenderDrawColor(rend, win ? 20:150, win ? 150:20, 20, 255);
        SDL_RenderClear(rend);
        SDL_RenderCopyEx(rend, tex, NULL, &dst, angle, NULL, SDL_FLIP_NONE);
        SDL_RenderPresent(rend);
        SDL_Delay(16);
    }
}

#include "minimap.h"
#include <stdlib.h>

/* ============================================================
   MINIMAP
   ============================================================ */

void init_minimap(MiniMap *m, SDL_Renderer *re) {
    m->img_map1  = IMG_LoadTexture(re, "map_level1.png");
    m->img_map2  = IMG_LoadTexture(re, "map_level2.png");
    m->img_point = IMG_LoadTexture(re, "point.png");
    m->img_mask1 = SDL_LoadBMP("mask_level1.bmp");
    m->img_mask2 = SDL_LoadBMP("mask_level2.bmp");
    m->num_level = 1;
    m->pos_map   = (SDL_Rect){10, 10, 200, 150};
    m->pos_point = (SDL_Rect){0, 0, 10, 10};
    m->joueur1X = 0; m->joueur1Y = 0;
    m->joueur2X = 0; m->joueur2Y = 0;
    m->shakeTimer = 0; m->shakeIntensity = 0;
    m->shakeOffsetX = 0; m->shakeOffsetY = 0;
}

void afficher_minimap(MiniMap m, SDL_Renderer *re) {
    SDL_Rect shaken = m.pos_map;
    shaken.x += m.shakeOffsetX;
    shaken.y += m.shakeOffsetY;
    if (m.num_level == 1)
        SDL_RenderCopy(re, m.img_map1, NULL, &shaken);
    else
        SDL_RenderCopy(re, m.img_map2, NULL, &shaken);
    SDL_RenderCopy(re, m.img_point, NULL, &m.pos_point);
}

void MAJ_minimap(MiniMap *m, int x, int y, int ratio) {
    m->joueur1X = x;
    m->joueur1Y = y;
    m->pos_point.x = m->pos_map.x + (x / ratio);
    m->pos_point.y = m->pos_map.y + (y / ratio);
    if (m->pos_point.x < m->pos_map.x) m->pos_point.x = m->pos_map.x;
    if (m->pos_point.y < m->pos_map.y) m->pos_point.y = m->pos_map.y;
    if (m->pos_point.x > m->pos_map.x + m->pos_map.w - m->pos_point.w)
        m->pos_point.x = m->pos_map.x + m->pos_map.w - m->pos_point.w;
    if (m->pos_point.y > m->pos_map.y + m->pos_map.h - m->pos_point.h)
        m->pos_point.y = m->pos_map.y + m->pos_map.h - m->pos_point.h;
}

int collision_PP(MiniMap *m, int x, int y) {
    SDL_Surface *mask = (m->num_level == 1) ? m->img_mask1 : m->img_mask2;
    if (!mask) return 0;
    if (x < 0 || y < 0 || x >= mask->w || y >= mask->h) return 0;
    Uint32 *pixels = (Uint32 *)mask->pixels;
    Uint8 r, g, b;
    SDL_GetRGB(pixels[y * mask->w + x], mask->format, &r, &g, &b);
    return (r == 0 && g == 0 && b == 0);
}

int collision_BB(SDL_Rect a, SDL_Rect b) {
    return (a.x < b.x + b.w && a.x + a.w > b.x &&
            a.y < b.y + b.h && a.y + a.h > b.y);
}

void minimap_trigger_shake(MiniMap *m) {
    if (m->shakeTimer <= 0) { m->shakeTimer = 15; m->shakeIntensity = 4; }
}

void minimap_update_shake(MiniMap *m) {
    if (m->shakeTimer > 0) {
        int intensity = m->shakeIntensity * m->shakeTimer / 15;
        if (intensity < 1) intensity = 1;
        m->shakeOffsetX = (rand() % (2 * intensity + 1)) - intensity;
        m->shakeOffsetY = (rand() % (2 * intensity + 1)) - intensity;
        m->shakeTimer--;
    } else {
        m->shakeOffsetX = 0;
        m->shakeOffsetY = 0;
    }
}

void liberer_minimap(MiniMap *m) {
    SDL_DestroyTexture(m->img_map1);
    SDL_DestroyTexture(m->img_map2);
    SDL_DestroyTexture(m->img_point);
    SDL_FreeSurface(m->img_mask1);
    SDL_FreeSurface(m->img_mask2);
}

/* ============================================================
   SOUS-MENU SAUVEGARDE
   ============================================================ */

SousMenu init_SousMenu(SDL_Renderer *re) {
    SousMenu sm;
    sm.img_bg        = IMG_LoadTexture(re, "images/sousmenu_bg.png");
    sm.pos_bg        = (SDL_Rect){200, 150, 400, 250};
    sm.btn_save[0]   = IMG_LoadTexture(re, "images/save_inactif.png");
    sm.btn_save[1]   = IMG_LoadTexture(re, "images/save_actif.png");
    sm.pos_save      = (SDL_Rect){300, 210, 200, 60};
    sm.btn_resume[0] = IMG_LoadTexture(re, "images/resume_inactif.png");
    sm.btn_resume[1] = IMG_LoadTexture(re, "images/resume_actif.png");
    sm.pos_resume    = (SDL_Rect){300, 300, 200, 60};
    sm.son_clic      = Mix_LoadWAV("sons/clic.wav");
    sm.musique       = Mix_LoadMUS("sons/musique_menu.ogg");
    sm.btn_actif     = 1;
    if (sm.musique) Mix_PlayMusic(sm.musique, -1);
    return sm;
}

void afficher_SousMenu(SousMenu sm, SDL_Renderer *re) {
    if (sm.img_bg) SDL_RenderCopy(re, sm.img_bg, NULL, &sm.pos_bg);
    if (sm.btn_actif == 1) SDL_RenderCopy(re, sm.btn_save[1],   NULL, &sm.pos_save);
    else                   SDL_RenderCopy(re, sm.btn_save[0],   NULL, &sm.pos_save);
    if (sm.btn_actif == 2) SDL_RenderCopy(re, sm.btn_resume[1], NULL, &sm.pos_resume);
    else                   SDL_RenderCopy(re, sm.btn_resume[0], NULL, &sm.pos_resume);
}

int update_SousMenu(SousMenu *sm, int input) {
    if (input == SDLK_DOWN) {
        if (sm->btn_actif < 2) sm->btn_actif++;
    } else if (input == SDLK_UP) {
        if (sm->btn_actif > 1) sm->btn_actif--;
    } else if (input == SDLK_RETURN) {
        if (sm->son_clic) Mix_PlayChannel(-1, sm->son_clic, 0);
        if (sm->btn_actif == 1) return -1; /* → sauvegarder */
        else                    return  3; /* → reprendre   */
    }
    return 0;
}

void liberer_SousMenu(SousMenu *sm) {
    SDL_DestroyTexture(sm->img_bg);
    SDL_DestroyTexture(sm->btn_save[0]);
    SDL_DestroyTexture(sm->btn_save[1]);
    SDL_DestroyTexture(sm->btn_resume[0]);
    SDL_DestroyTexture(sm->btn_resume[1]);
    Mix_FreeChunk(sm->son_clic);
    Mix_FreeMusic(sm->musique);
}

/* ============================================================
   SAUVEGARDE / CHARGEMENT
   ============================================================ */

void sauvegarder_jeu(MiniMap m, int score,
                     int sang1, int sang2,
                     int timer, int cameraX, int cameraY,
                     int nb_cles, char *nomF)
{
    FILE *f = fopen(nomF, "wb");
    if (!f) return;
    fwrite(&m.joueur1X,  sizeof(int), 1, f);
    fwrite(&m.joueur1Y,  sizeof(int), 1, f);
    fwrite(&m.joueur2X,  sizeof(int), 1, f);
    fwrite(&m.joueur2Y,  sizeof(int), 1, f);
    fwrite(&m.num_level, sizeof(int), 1, f);
    fwrite(&nb_cles,     sizeof(int), 1, f);
    fwrite(&score,       sizeof(int), 1, f);
    fwrite(&sang1,       sizeof(int), 1, f);
    fwrite(&sang2,       sizeof(int), 1, f);
    fwrite(&timer,       sizeof(int), 1, f);
    fwrite(&cameraX,     sizeof(int), 1, f);
    fwrite(&cameraY,     sizeof(int), 1, f);
    fclose(f);
}

void charger_jeu(MiniMap *m, int *score,
                 int *sang1, int *sang2,
                 int *timer, int *cameraX, int *cameraY,
                 int *nb_cles, char *nomF)
{
    FILE *f = fopen(nomF, "rb");
    if (!f) return;
    fread(&m->joueur1X,  sizeof(int), 1, f);
    fread(&m->joueur1Y,  sizeof(int), 1, f);
    fread(&m->joueur2X,  sizeof(int), 1, f);
    fread(&m->joueur2Y,  sizeof(int), 1, f);
    fread(&m->num_level, sizeof(int), 1, f);
    fread(nb_cles,       sizeof(int), 1, f);
    fread(score,         sizeof(int), 1, f);
    fread(sang1,         sizeof(int), 1, f);
    fread(sang2,         sizeof(int), 1, f);
    fread(timer,         sizeof(int), 1, f);
    fread(cameraX,       sizeof(int), 1, f);
    fread(cameraY,       sizeof(int), 1, f);
    fclose(f);
}

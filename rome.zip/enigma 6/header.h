/**
 * @file header.h
 * @brief Header file for Enigme 6 - SDL2 drag-and-drop puzzle game
 * @author C Team
 * @date May 09, 2026
 * @version 1.0
 */

#pragma once
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define W    800  /*!< Window width in pixels */
#define H    500  /*!< Window height in pixels */
#define BG_X 10   /*!< Background X position */
#define BG_Y 10   /*!< Background Y position */
#define BG_W 560  /*!< Background width */
#define BG_H 480  /*!< Background height */
#define PW   120  /*!< Piece width */
#define PH   110  /*!< Piece height */
#define NB   5    /*!< Number of puzzle images available */
#define TMAX 30000 /*!< Time limit in milliseconds (30 seconds) */
#define SNAP 60   /*!< Snap distance in pixels for piece placement */

/**
 * @struct Puzzle
 * @brief Represents a puzzle with a hole and candidate pieces
 */
typedef struct {
    SDL_Rect hole;    /*!< The hole rectangle on the board */
    SDL_Rect src[3];  /*!< Source rectangles for the 3 candidate pieces */
    int correct;      /*!< Index of the correct piece */
} Puzzle;

/**
 * @struct Piece
 * @brief Represents a draggable puzzle piece
 */
typedef struct {
    SDL_Rect src;   /*!< Source rectangle from the texture */
    SDL_Rect pos;   /*!< Current position on screen */
    SDL_Rect orig;  /*!< Original slot position (for snapping back) */
    int drag;       /*!< 1 if currently being dragged, 0 otherwise */
    int placed;     /*!< 1 if correctly placed, 0 otherwise */
    int correct;    /*!< 1 if this is the correct piece for the hole */
} Piece;

extern int score; /*!< Global score shared across modules */

int  load_resources (SDL_Renderer *rend, int fate,
                     SDL_Texture **bg,
                     Mix_Chunk   **snd,
                     TTF_Font    **fnt,
                     SDL_Texture **wTex,
                     SDL_Texture **lTex);

void free_resources (SDL_Texture *bg,
                     SDL_Texture *wTex, SDL_Texture *lTex,
                     Mix_Chunk   *snd,  TTF_Font    *fnt);

void init_puzzle    (SDL_Texture *bg,
                     Piece pc[3], SDL_Rect slots[3],
                     SDL_Rect *hScr, SDL_Rect *target);

void on_quit        (int *run, int *result);

void on_mouse_down  (SDL_MouseButtonEvent *ev,
                     Piece pc[3],
                     int *dIdx, int *ox, int *oy);

void on_mouse_motion(SDL_MouseMotionEvent *ev,
                     Piece pc[3], int dIdx, int ox, int oy);

void on_mouse_up    (SDL_MouseButtonEvent *ev,
                     Piece pc[3], SDL_Rect target,
                     int *dIdx,
                     int *run, int *result);

void render_frame   (SDL_Renderer *rend, SDL_Texture *bg,
                     Piece pc[3], SDL_Rect hScr,
                     Uint32 elapsed);

void rotozoom       (SDL_Renderer *rend,
                     SDL_Texture *tex, int win);

int  enigme2        (SDL_Renderer *rend, int fate, int *solved);

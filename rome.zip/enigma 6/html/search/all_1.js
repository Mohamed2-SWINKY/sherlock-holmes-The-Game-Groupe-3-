var searchData=
[
  ['correct_0',['correct',['../structPuzzle.html#ad79b0970aa1920b173006d4beacd541d',1,'Puzzle::correct'],['../structPiece.html#ab8f8696e6d9d7d6a5b68368c2a16f70c',1,'Piece::correct']]]
];

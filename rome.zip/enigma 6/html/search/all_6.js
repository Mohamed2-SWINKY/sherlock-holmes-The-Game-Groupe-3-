var searchData=
[
  ['h_0',['H',['../header_8h.html#abec92cc72a096640b821b8cd56a02495',1,'header.h']]],
  ['header_2eh_1',['header.h',['../header_8h.html',1,'']]],
  ['hole_2',['hole',['../structPuzzle.html#abd89b9b7a1c553617ebe0d6f4a0197f2',1,'Puzzle']]]
];

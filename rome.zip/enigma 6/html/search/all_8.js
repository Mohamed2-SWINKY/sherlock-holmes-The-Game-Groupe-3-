var searchData=
[
  ['load_5fresources_0',['load_resources',['../header_8h.html#a47c2dd6cfdbac9eea1c37b88e1feaa31',1,'load_resources(SDL_Renderer *rend, int fate, SDL_Texture **bg, Mix_Chunk **snd, TTF_Font **fnt, SDL_Texture **wTex, SDL_Texture **lTex):&#160;rss.c'],['../rss_8c.html#a47c2dd6cfdbac9eea1c37b88e1feaa31',1,'load_resources(SDL_Renderer *rend, int fate, SDL_Texture **bg, Mix_Chunk **snd, TTF_Font **fnt, SDL_Texture **wTex, SDL_Texture **lTex):&#160;rss.c']]]
];

var searchData=
[
  ['placed_0',['placed',['../structPiece.html#a572233724cef3023be12e227662a1a87',1,'Piece']]],
  ['pos_1',['pos',['../structPiece.html#a1dd9bcd678c9bab581c8f35af51cc098',1,'Piece']]]
];

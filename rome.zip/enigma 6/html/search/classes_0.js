var searchData=
[
  ['piece_0',['Piece',['../structPiece.html',1,'']]],
  ['puzzle_1',['Puzzle',['../structPuzzle.html',1,'']]]
];

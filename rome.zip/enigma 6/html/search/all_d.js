var searchData=
[
  ['render_5fframe_0',['render_frame',['../header_8h.html#a324a7f6225d0c1f690c66618334efb52',1,'render_frame(SDL_Renderer *rend, SDL_Texture *bg, Piece pc[3], SDL_Rect hScr, Uint32 elapsed):&#160;rss.c'],['../rss_8c.html#a324a7f6225d0c1f690c66618334efb52',1,'render_frame(SDL_Renderer *rend, SDL_Texture *bg, Piece pc[3], SDL_Rect hScr, Uint32 elapsed):&#160;rss.c']]],
  ['rotozoom_1',['rotozoom',['../header_8h.html#ac29c5bcb396043b6508f65657b428275',1,'rotozoom(SDL_Renderer *rend, SDL_Texture *tex, int win):&#160;rss.c'],['../rss_8c.html#ac29c5bcb396043b6508f65657b428275',1,'rotozoom(SDL_Renderer *rend, SDL_Texture *tex, int win):&#160;rss.c']]],
  ['rss_2ec_2',['rss.c',['../rss_8c.html',1,'']]]
];

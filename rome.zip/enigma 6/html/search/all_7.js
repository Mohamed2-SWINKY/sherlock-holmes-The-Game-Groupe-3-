var searchData=
[
  ['init_5fpuzzle_0',['init_puzzle',['../header_8h.html#a24b4a934e4c7c21526524a073ae0717c',1,'init_puzzle(SDL_Texture *bg, Piece pc[3], SDL_Rect slots[3], SDL_Rect *hScr, SDL_Rect *target):&#160;rss.c'],['../rss_8c.html#a24b4a934e4c7c21526524a073ae0717c',1,'init_puzzle(SDL_Texture *bg, Piece pc[3], SDL_Rect slots[3], SDL_Rect *hScr, SDL_Rect *target):&#160;rss.c']]]
];

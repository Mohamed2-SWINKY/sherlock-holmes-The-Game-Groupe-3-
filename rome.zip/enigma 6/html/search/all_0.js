var searchData=
[
  ['bg_5fh_0',['BG_H',['../header_8h.html#abe6d916ecd5fe37b0be49f5a0cfa1e59',1,'header.h']]],
  ['bg_5fw_1',['BG_W',['../header_8h.html#ada8fc72d5a6335b685c280c9ae0e17d5',1,'header.h']]],
  ['bg_5fx_2',['BG_X',['../header_8h.html#a3206fe231afb183d5d0aa3c9b188d881',1,'header.h']]],
  ['bg_5fy_3',['BG_Y',['../header_8h.html#ae517468382caa06ef6c4cfb7ef2296b7',1,'header.h']]]
];

var searchData=
[
  ['hole_0',['hole',['../structPuzzle.html#abd89b9b7a1c553617ebe0d6f4a0197f2',1,'Puzzle']]]
];

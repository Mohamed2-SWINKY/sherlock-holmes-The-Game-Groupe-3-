var searchData=
[
  ['orig_0',['orig',['../structPiece.html#a194cb078989bf0432cec9789cb0de891',1,'Piece']]]
];

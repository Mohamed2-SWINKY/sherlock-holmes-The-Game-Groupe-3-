var searchData=
[
  ['ph_0',['PH',['../header_8h.html#ae0fcc909f5a4166b625a6707cbdfa643',1,'header.h']]],
  ['piece_1',['Piece',['../structPiece.html',1,'']]],
  ['placed_2',['placed',['../structPiece.html#a572233724cef3023be12e227662a1a87',1,'Piece']]],
  ['pos_3',['pos',['../structPiece.html#a1dd9bcd678c9bab581c8f35af51cc098',1,'Piece']]],
  ['puzzle_4',['Puzzle',['../structPuzzle.html',1,'']]],
  ['pw_5',['PW',['../header_8h.html#a80665c70b5c319208328ddbb0e1fba7a',1,'header.h']]]
];

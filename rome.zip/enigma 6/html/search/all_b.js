var searchData=
[
  ['on_5fmouse_5fdown_0',['on_mouse_down',['../header_8h.html#a2d9cb4422b1459f092e7ce6cc53cd68f',1,'on_mouse_down(SDL_MouseButtonEvent *ev, Piece pc[3], int *dIdx, int *ox, int *oy):&#160;rss.c'],['../rss_8c.html#a2d9cb4422b1459f092e7ce6cc53cd68f',1,'on_mouse_down(SDL_MouseButtonEvent *ev, Piece pc[3], int *dIdx, int *ox, int *oy):&#160;rss.c']]],
  ['on_5fmouse_5fmotion_1',['on_mouse_motion',['../header_8h.html#a4acc468a2bd5a6c9012dcce053caea6b',1,'on_mouse_motion(SDL_MouseMotionEvent *ev, Piece pc[3], int dIdx, int ox, int oy):&#160;rss.c'],['../rss_8c.html#a4acc468a2bd5a6c9012dcce053caea6b',1,'on_mouse_motion(SDL_MouseMotionEvent *ev, Piece pc[3], int dIdx, int ox, int oy):&#160;rss.c']]],
  ['on_5fmouse_5fup_2',['on_mouse_up',['../header_8h.html#a3143737352d8acd59dc00d967a0899e9',1,'on_mouse_up(SDL_MouseButtonEvent *ev, Piece pc[3], SDL_Rect target, int *dIdx, int *run, int *result):&#160;rss.c'],['../rss_8c.html#a3143737352d8acd59dc00d967a0899e9',1,'on_mouse_up(SDL_MouseButtonEvent *ev, Piece pc[3], SDL_Rect target, int *dIdx, int *run, int *result):&#160;rss.c']]],
  ['on_5fquit_3',['on_quit',['../header_8h.html#a6d08d85d287d9a8549200870b92702f1',1,'on_quit(int *run, int *result):&#160;rss.c'],['../rss_8c.html#a6d08d85d287d9a8549200870b92702f1',1,'on_quit(int *run, int *result):&#160;rss.c']]],
  ['orig_4',['orig',['../structPiece.html#a194cb078989bf0432cec9789cb0de891',1,'Piece']]]
];

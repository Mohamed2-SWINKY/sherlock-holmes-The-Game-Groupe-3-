var searchData=
[
  ['snap_0',['SNAP',['../header_8h.html#a412d86d178eb9541a56456526d26caff',1,'header.h']]]
];

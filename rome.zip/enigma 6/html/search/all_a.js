var searchData=
[
  ['nb_0',['NB',['../header_8h.html#a58e95dc1eb9d6ce16f515e77beeadd58',1,'header.h']]]
];

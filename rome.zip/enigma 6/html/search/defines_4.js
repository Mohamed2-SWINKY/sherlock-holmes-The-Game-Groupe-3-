var searchData=
[
  ['ph_0',['PH',['../header_8h.html#ae0fcc909f5a4166b625a6707cbdfa643',1,'header.h']]],
  ['pw_1',['PW',['../header_8h.html#a80665c70b5c319208328ddbb0e1fba7a',1,'header.h']]]
];

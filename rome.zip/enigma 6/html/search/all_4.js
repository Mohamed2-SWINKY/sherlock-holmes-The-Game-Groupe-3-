var searchData=
[
  ['free_5fresources_0',['free_resources',['../header_8h.html#a08e1abe0da5bfa1bf2f472efa3ea693e',1,'free_resources(SDL_Texture *bg, SDL_Texture *wTex, SDL_Texture *lTex, Mix_Chunk *snd, TTF_Font *fnt):&#160;rss.c'],['../rss_8c.html#a08e1abe0da5bfa1bf2f472efa3ea693e',1,'free_resources(SDL_Texture *bg, SDL_Texture *wTex, SDL_Texture *lTex, Mix_Chunk *snd, TTF_Font *fnt):&#160;rss.c']]]
];

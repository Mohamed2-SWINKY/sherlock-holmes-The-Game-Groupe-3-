var searchData=
[
  ['enigme2_0',['enigme2',['../header_8h.html#af1a0bd61f51f264fa1400e97866d2ca4',1,'enigme2(SDL_Renderer *rend, int fate, int *solved):&#160;rss.c'],['../rss_8c.html#af1a0bd61f51f264fa1400e97866d2ca4',1,'enigme2(SDL_Renderer *rend, int fate, int *solved):&#160;rss.c']]]
];

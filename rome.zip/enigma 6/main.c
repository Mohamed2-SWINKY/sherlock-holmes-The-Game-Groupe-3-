/**
 * @file main.c
 * @brief Entry point for Enigme 6 - SDL2 puzzle game
 * @author C Team
 * @date May 09, 2026
 * @version 1.0
 *
 * Initializes SDL2 and all subsystems, launches the puzzle game,
 * then cleans up on exit.
 */

#include "header.h"

/**
 * @brief Main entry point of the program
 * @return 0 on success
 */
int main() {
    srand(time(NULL));
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    IMG_Init(IMG_INIT_PNG | IMG_INIT_JPG);
    TTF_Init();
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

    SDL_Window   *win  = SDL_CreateWindow("Enigme 2",
                            SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                            W, H, 0);
    SDL_Renderer *rend = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

    int solved = 0;
    int fate = rand() % NB;
    enigme2(rend, fate, &solved);

    Mix_CloseAudio();
    TTF_Quit();
    IMG_Quit();
    SDL_DestroyRenderer(rend);
    SDL_DestroyWindow(win);
    SDL_Quit();
    return 0;
}

#ifndef QUIZ_H
#define QUIZ_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_image.h>

#define MAX 50

typedef struct {
    char question[256];
    char A[100];
    char B[100];
    char C[100];
    char correcte;
    int dejaVu;
} Enigme;

int charger(Enigme t[], int *n);
int generer(Enigme t[], int n);

SDL_Texture* renderText(char *msg, TTF_Font *font, SDL_Color color, SDL_Renderer *renderer);
void drawText(SDL_Texture *tex, int x, int y, SDL_Renderer *renderer);

#endif


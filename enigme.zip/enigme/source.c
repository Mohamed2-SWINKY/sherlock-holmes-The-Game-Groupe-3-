#include "header.h"
#include <stdio.h>
#include <stdlib.h>

int charger(Enigme t[], int *n) {
    FILE *f = fopen("questions.txt", "r");
    if (!f) return 0;

    *n = 0;
    while (!feof(f)) {
        fscanf(f, "Q: %[^\n]\n", t[*n].question);
        fscanf(f, "A: %[^\n]\n", t[*n].A);
        fscanf(f, "B: %[^\n]\n", t[*n].B);
        fscanf(f, "C: %[^\n]\n", t[*n].C);
        fscanf(f, "R: %c\n\n", &t[*n].correcte);
        t[*n].dejaVu = 0;
        (*n)++;
    }

    fclose(f);
    return 1;
}

int generer(Enigme t[], int n) {
    int i;
    do {
        i = rand() % n;
    } while (t[i].dejaVu);

    t[i].dejaVu = 1;
    return i;
}

SDL_Texture* renderText(char *msg, TTF_Font *font, SDL_Color color, SDL_Renderer *renderer) {
    SDL_Surface *surf = TTF_RenderUTF8_Blended(font, msg, color);
    SDL_Texture *tex = SDL_CreateTextureFromSurface(renderer, surf);
    SDL_FreeSurface(surf);
    return tex;
}

void drawText(SDL_Texture *tex, int x, int y, SDL_Renderer *renderer) {
    SDL_Rect r;
    SDL_QueryTexture(tex, NULL, NULL, &r.w, &r.h);
    r.x = x;
    r.y = y;
    SDL_RenderCopy(renderer, tex, NULL, &r);
}



